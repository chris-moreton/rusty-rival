import chess,chess.engine,json,hashlib
from pathlib import Path
root=Path('/tmp/rival-epd-round')
engines={'rival':root/'rusty-rival-v1.0.68-linux-x86_64-avx2','stash':Path('/tmp/rival-epd-stash/src/stash'),'ethereal':Path('/tmp/rival-epd-ethereal/src/Ethereal'),'stockfish':root/'stockfish/stockfish-linux-x86-64-universal'}
# Preselected before five-second result: historical persistent failures spanning
# defensive king resource, attacking king route, and quiet rook retreat.
ids=['049','060','081']
positions=[]
for l in Path('epd/suites/eet.epd').read_text().splitlines():
 if l.strip():
  b,ops=chess.Board.from_epd(l)
  if any(' '+i+' ' in ops['id'] for i in ids): positions.append((b,ops))
out=[]
for b,ops in positions:
 row={'id':ops['id'],'fen':b.fen(),'expected':[m.uci() for m in ops.get('bm',[])],'engines':{}}
 for name,path in engines.items():
  with chess.engine.SimpleEngine.popen_uci(str(path),timeout=60) as e:
   opts={k:v for k,v in {'Threads':1,'Hash':128,'SyzygyPath':'','Ponder':False}.items() if k in e.options and k!='Ponder'}
   e.configure(opts)
   info=e.analyse(b,chess.engine.Limit(time=5))
   def convert(i):
    return {'score':i['score'].pov(b.turn).score(mate_score=32000),'mate':i['score'].pov(b.turn).mate(),'depth':i.get('depth'),'nodes':i.get('nodes'),'pv':[m.uci() for m in i.get('pv',[])],'san':b.variation_san(i.get('pv',[])),'tbhits':i.get('tbhits')}
   row['engines'][name]={'root':convert(info),'forced':{}}
   # Same teacher, same time, independently clear TT for each forced root move.
   candidates=set(ops.get('bm',[]))|{info['pv'][0]}
   if name=='stockfish':candidates|={chess.Move.from_uci(v['root']['pv'][0]) for v in row['engines'].values()}
   for move in sorted(candidates,key=lambda m:m.uci()):
    forced=e.analyse(b,chess.engine.Limit(time=5),root_moves=[move],game=object())
    row['engines'][name]['forced'][move.uci()]=convert(forced)
  print(ops['id'],name,row['engines'][name],flush=True)
 out.append(row);(root/'diagnosis.json').write_text(json.dumps(out,indent=2))
