from pathlib import Path
import subprocess,tarfile,io,hashlib,json
root=Path('/tmp/rival-epd-round'); source=root/'diagnostic-source'
assert not source.exists()
archive=subprocess.check_output(['git','archive','4177cab'])
source.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(source,filter='data')
p=source/'src/search.rs'; original=p.read_text()
old='if excluded_move == 0 && hash_entry.height >= depth {'
assert original.count(old)==1
new='if excluded_move == 0 && hash_entry.height >= depth && (window.1 - window.0 == 1 || !epd_disable_pv_tt()) {'
helper='// Investigation-only switch. Not a proposed production change or timed binary.\nfn epd_disable_pv_tt() -> bool {\n    static DISABLED: std::sync::LazyLock<bool> = std::sync::LazyLock::new(|| {\n        std::env::var_os("RIVAL_EPD_DISABLE_PV_TT").is_some()\n    });\n    *DISABLED\n}\n\n'
p.write_text(helper+original.replace(old,new))
(root/'diagnostic-source.patch').write_text(subprocess.run(['diff','-u','/home/chris/Work/rusty-rival/rusty-rival/src/search.rs',str(p)],capture_output=True,text=True).stdout)
(root/'diagnostic-source.json').write_text(json.dumps({'commit':'4177cab','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'purpose':'diagnostic causal intervention, never a release candidate'},indent=2))
