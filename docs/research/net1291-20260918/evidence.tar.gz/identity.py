import sys,os,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from compare_search_speed import sample_fens,search
root=Path('/tmp/rival-epd-round');base=root/'rusty-rival-v1.0.68-linux-x86_64-avx2';diag=root/'diagnostic-target/release/rusty-rival'
assert 'RIVAL_EPD_DISABLE_PV_TT' not in os.environ
out={'binary_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base,diag]},'nodes':100000,'positions':[]}
for i,fen in enumerate(sample_fens(Path.cwd())):
 a=search(base,fen,100000);b=search(diag,fen,100000)
 out['positions'].append({'fen':fen,'baseline':a,'diagnostic_off':b,'equal':a==b})
 (root/'identity.json').write_text(json.dumps(out,indent=2))
 if a!=b:raise AssertionError(f'Control divergence at {i}')
print('PASS',len(out['positions']),flush=True)
