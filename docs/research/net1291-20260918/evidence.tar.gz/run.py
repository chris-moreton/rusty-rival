import subprocess,json,hashlib,time
from pathlib import Path
root=Path('/tmp/rival-epd-round')
engines={'rival':'/tmp/rival-epd-round/rusty-rival-v1.0.68-linux-x86_64-avx2','stash':'/tmp/rival-epd-stash/src/stash','ethereal':'/tmp/rival-epd-ethereal/src/Ethereal'}
manifest={'purpose':'diagnostic only; no strength claim or parameter selection','budgets_seconds':[1,5],'threads':1,'hash_mb':128,'concurrency':4,'engines':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in engines.items()},'start':time.time()}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
for budget in [1,5]:
 for name,path in engines.items():
  command=['target/release/epd-runner','--epd-dir',str(root/'epd'),'run','--engine',path,'--family',name,'--label',name,'--suites','eet','--time',str(budget),'--threads','1','--hash','128','--concurrency','4']
  with (root/f'{name}-{budget}s.log').open('w') as log:
   r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  print(name,budget,r.returncode,flush=True)
  if r.returncode: raise SystemExit(r.returncode)
manifest['finish']=time.time(); (root/'manifest.json').write_text(json.dumps(manifest,indent=2))
