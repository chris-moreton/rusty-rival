import subprocess,time
from pathlib import Path
root=Path('/tmp/rival-epd-round')
for name,path in [('stash','/tmp/rival-epd-stash/src/stash'),('ethereal','/tmp/rival-epd-ethereal/src/Ethereal')]:
 deadline=time.monotonic()+180
 while float(Path('/proc/loadavg').read_text().split()[0])>3.5:
  if time.monotonic()>deadline:raise RuntimeError('Host did not settle')
  time.sleep(5)
 with (root/f'{name}-5s-retry.log').open('w') as log:
  r=subprocess.run(['target/release/epd-runner','--epd-dir',str(root/'epd'),'run','--engine',path,'--family',name,'--label',name,'--suites','eet','--time','5','--threads','1','--hash','128','--concurrency','4'],stdout=log,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
