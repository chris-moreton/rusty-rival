import json,chess
from pathlib import Path
root=Path('/tmp/rival-epd-round');classes={}
for l in (root/'epd/suites/eet.epd').read_text().splitlines():
 if not l.strip():continue
 b,o=chess.Board.from_epd(l);material=b.board_fen().lower()
 cls='queen' if 'q' in material else 'rook' if 'r' in material else 'minor' if 'b' in material or 'n' in material else 'pawn'
 classes[' '.join(o['id'].split())]=cls
out={}
for f in (root/'epd/results').glob('*/*.json'):
 d=json.loads(f.read_text())
 for r in d['runs']:
  counts={c:[0,0] for c in ['pawn','minor','queen','rook']}
  for p in r['positions']:
   c=classes[p['id']];counts[c][1]+=1;counts[c][0]+=p['solved']
  out[d['engine']['family']+'-'+str(r['budget'])]=counts
(root/'classes.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
