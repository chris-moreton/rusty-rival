import os,sys,json,re
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from compare_search_speed import search
root=Path('/tmp/rival-epd-round');base=root/'rusty-rival-v1.0.68-linux-x86_64-avx2';diag=root/'diagnostic-target/release/rusty-rival';rows=[]
positions={}
for line in Path('epd/suites/eet.epd').read_text().splitlines():
 if any('E_E_T '+x+' ' in line for x in ['036','049','053','060','081']):
  positions[re.search(r'id "([^"]+)"',line).group(1)]=' '.join(line.split()[:4])+' 0 1'
positions.update({'parent':'1k6/8/2K5/8/5p2/6p1/4Pp1p/R7 b - - 1 2','child':'1k6/8/2K5/8/5p2/8/4Pppp/R7 w - - 0 3'})
for name,fen in positions.items():
 row={'id':name,'fen':fen,'nodes':1000000,'arms':{}}
 for arm,binary,on in [('control',base,False),('no-pv-tt',diag,True)]:
  os.environ.pop('RIVAL_EPD_DISABLE_PV_TT',None)
  if on:os.environ['RIVAL_EPD_DISABLE_PV_TT']='1'
  row['arms'][arm]=search(binary,fen,1000000)
  print(name,arm,row['arms'][arm]['bestmove'],row['arms'][arm]['info'][-1],flush=True)
 rows.append(row);(root/'selected.json').write_text(json.dumps(rows,indent=2))
