import json
from pathlib import Path
root=Path('/tmp/rival-epd-round');ds={}
for f in (root/'epd/results/diagnostic').glob('*.json'):
 d=json.loads(f.read_text());ds[d['engine']['label']]=d
out=[]
if len(ds)==2:
 a={r['suite']['name']:r for r in ds['control']['runs']};b={r['suite']['name']:r for r in ds['no-pv-tt']['runs']}
 for name,x in a.items():
  if name not in b:continue
  y=b[name];p={z['id']:z for z in x['positions']};q={z['id']:z for z in y['positions']}
  assert p.keys()==q.keys()
  row={'suite':name,'control':x['summary'],'no_pv_tt':y['summary'],'gains':[i for i in p if not p[i]['solved'] and q[i]['solved']],'losses':[i for i in p if p[i]['solved'] and not q[i]['solved']]}
  out.append(row)
(root/'diagnostic-comparison.json').write_text(json.dumps(out,indent=2))
for r in out:print(r['suite'],r['control']['solved'],r['no_pv_tt']['solved'],'gains',len(r['gains']),'losses',len(r['losses']))
