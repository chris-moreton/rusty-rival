import chess,json,urllib.request,urllib.parse,time
from pathlib import Path
out=[]
for line in Path('epd/suites/eet.epd').read_text().splitlines():
 if not line.strip():continue
 b,ops=chess.Board.from_epd(line)
 if len(b.piece_map())>7:continue
 url='https://tablebase.lichess.ovh/standard?'+urllib.parse.urlencode({'fen':b.fen()})
 with urllib.request.urlopen(url,timeout=60) as r:d=json.load(r)
 out.append({'id':ops['id'],'fen':b.fen(),'expected':[m.uci() for m in ops.get('bm',[])],'response':d})
 Path('/tmp/rival-epd-round/tablebase-audit.json').write_text(json.dumps(out,indent=2))
 print(ops['id'],d['category'],[(m['san'],m['category'],m['dtz']) for m in d['moves'][:8]],flush=True)
 time.sleep(1)
