import os,sys,subprocess,json
from pathlib import Path
root=Path('/tmp/rival-epd-round');repo=Path.cwd()
def run(cmd,name,env=None):
 with (root/(name+'.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run(['python3',str(root/'identity.py')],'identity')
run([str(root/'venv/bin/python'),str(root/'boundary.py')],'boundary')
for name,binary,toggle in [('control',root/'rusty-rival-v1.0.68-linux-x86_64-avx2',False),('no-pv-tt',root/'diagnostic-target/release/rusty-rival',True)]:
 env=os.environ.copy();env.pop('RIVAL_EPD_DISABLE_PV_TT',None)
 if toggle:env['RIVAL_EPD_DISABLE_PV_TT']='1'
 run([str(repo/'target/release/epd-runner'),'--epd-dir',str(root/'epd'),'run','--engine',str(binary),'--family','diagnostic','--label',name,'--suites','all','--nodes','100000','--threads','1','--hash','128','--concurrency','4'],name+'-all-100k',env)
