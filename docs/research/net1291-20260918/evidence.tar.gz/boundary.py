import chess,chess.engine,json,logging
from pathlib import Path
root=Path('/tmp/rival-epd-round')
logging.basicConfig(filename=str(root/'boundary-uci.log'),level=logging.DEBUG)
positions={'parent':'1k6/8/2K5/8/5p2/6p1/4Pp1p/R7 b - - 1 2','child':'1k6/8/2K5/8/5p2/8/4Pppp/R7 w - - 0 3'}
rows=[]
for name,fen in positions.items():
 for mb in [96,128,192]:
  for forced in ([None,'g3g2'] if name=='parent' else [None]):
   with chess.engine.SimpleEngine.popen_uci(str(root/'rusty-rival-v1.0.68-linux-x86_64-avx2')) as e:
    e.configure({'Threads':1,'Hash':mb})
    b=chess.Board(fen);i=e.analyse(b,chess.engine.Limit(nodes=1000000),root_moves=[chess.Move.from_uci(forced)] if forced else None)
    r={'name':name,'fen':fen,'hash_mb':mb,'forced':forced,'score_white':i['score'].white().score(mate_score=32000),'depth':i.get('depth'),'nodes':i.get('nodes'),'lowerbound':i.get('lowerbound',False),'upperbound':i.get('upperbound',False),'pv':[m.uci() for m in i.get('pv',[])]}
    rows.append(r);print(r,flush=True)
(root/'boundary.json').write_text(json.dumps(rows,indent=2))
