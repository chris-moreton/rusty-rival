import chess,chess.engine,subprocess,json
from pathlib import Path
root=Path('/tmp/rival-epd-round');rival=str(root/'rusty-rival-v1.0.68-linux-x86_64-avx2')
b=chess.Board('1k6/8/8/1K6/5pp1/8/4Pp1p/R7 w - - 0 1');pv='b5b6 g4g3 b6c6 g3g2 a1b1 b8c8 b1a1'.split();out=[]
for ply in range(len(pv)+1):
 row={'ply':ply,'fen':b.fen(),'expected':pv[ply] if ply<len(pv) else None}
 for hce in [False,True]:
  cmds='uci\nsetoption name UseNNUE value '+str(not hce).lower()+'\nposition fen '+b.fen()+'\neval\nquit\n'
  lines=subprocess.run([rival],input=cmds,text=True,capture_output=True,timeout=15).stdout.splitlines()
  row['hce' if hce else 'nnue']=[l for l in lines if 'eval raw' in l]
 with chess.engine.SimpleEngine.popen_uci(rival) as e:
  e.configure({'Threads':1,'Hash':128})
  i=e.analyse(b,chess.engine.Limit(nodes=1000000))
  row['search']={'score_white':i['score'].white().score(mate_score=32000),'depth':i.get('depth'),'nodes':i.get('nodes'),'pv':[m.uci() for m in i.get('pv',[])],'san':b.variation_san(i.get('pv',[]))}
 out.append(row);print(row,flush=True)
 if ply<len(pv):b.push_uci(pv[ply])
(root/'walk.json').write_text(json.dumps(out,indent=2))
