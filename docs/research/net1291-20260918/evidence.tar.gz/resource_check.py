import chess,json
from pathlib import Path
fen='1k6/8/8/1K6/5pp1/8/4Pp1p/R7 w - - 0 1'
rows=[]
for moves in ['b5b6 g4g3 b6c6 g3g2 a1b1 b8c8 b1a1 h2h1q','b5c6 g4g3 a1b1 b8c8 b1a1 h2h1q']:
 b=chess.Board(fen)
 for s in moves.split(): assert chess.Move.from_uci(s) in b.legal_moves;b.push_uci(s)
 r={'moves':moves,'fen':b.fen(),'promotion_checks':b.is_check(),'ra8_legal':chess.Move.from_uci('a1a8') in b.legal_moves}
 if r['ra8_legal']:b.push_uci('a1a8');r['ra8_mates']=b.is_checkmate()
 rows.append(r)
Path('/tmp/rival-epd-round/resource-check.json').write_text(json.dumps(rows,indent=2))
