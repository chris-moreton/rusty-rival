import json,re
from pathlib import Path
root=Path('/tmp/rival-epd-round')
runs={}
for f in (root/'epd/results').glob('*/*.json'):
 d=json.loads(f.read_text())
 for r in d['runs']: runs[d['engine']['family'],r['budget']]={p['id']:p for p in r['positions']}
fen={' '.join(re.search(r'id "([^"]+)"',l).group(1).split()):' '.join(l.split()[:4])+' 0 1' for l in (root/'epd/suites/eet.epd').read_text().splitlines() if l.strip() and not l.startswith('#')}
report={'totals':{},'disagreements':{}}
for budget in [1000,5000]:
 keys=[k for k in runs if k[1]==budget]
 report['totals'][budget]={k[0]:sum(p['solved'] for p in runs[k].values()) for k in keys}
 if len(keys)<3:continue
 rr=runs['rival',budget]
 report['disagreements'][budget]=[{'id':i,'fen':fen[i],'pieces':sum(c.isalpha() for c in fen[i].split()[0]),'engines':{k[0]:runs[k][i] for k in keys}} for i,p in rr.items() if not p['solved'] and all(runs[k][i]['solved'] for k in keys if k[0]!='rival')]
(root/'comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report['totals']))
for b,rows in report['disagreements'].items():
 print(b,[(r['id'],r['pieces'],{k:(v['best'],v.get('score_cp')) for k,v in r['engines'].items()}) for r in rows])
