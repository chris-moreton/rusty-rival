import chess,chess.engine,json
from pathlib import Path
root=Path('/tmp/rival-epd-round');out=[]
for r in json.loads((root/'tablebase-audit.json').read_text()):
 with chess.engine.SimpleEngine.popen_uci(str(root/'stockfish/stockfish-linux-x86-64-universal')) as e:
  e.configure({'Threads':1,'Hash':128,'SyzygyPath':''})
  b=chess.Board(r['fen']);i=e.analyse(b,chess.engine.Limit(nodes=1000000));mv=i['pv'][0].uci()
  out.append({'id':r['id'],'move':mv,'root_category':r['response']['category'],'chosen_child_category':next(m['category'] for m in r['response']['moves'] if m['uci']==mv),'score':i['score'].pov(b.turn).score(mate_score=32000),'nodes':i.get('nodes'),'pv':[m.uci() for m in i['pv']],'tbhits':i.get('tbhits')})
(root/'tb-reference.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
