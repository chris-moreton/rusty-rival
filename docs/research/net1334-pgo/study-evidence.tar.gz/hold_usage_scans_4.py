"""Temporarily defer desktop usage transcript rescans using their existing locks."""
import fcntl,json,time
from pathlib import Path
root=Path('/tmp/rival-pgo/study')
status=root/'usage-scan-hold-4.json';release=root/'usage-scan-hold-4.release'
assert not release.exists(),'Use a fresh hold after removing the old release marker deliberately'
paths=sorted((Path.home()/'.cache/omarchy/agent-usage').glob('*-scan-*.lock'))
assert len(paths)==2 and {p.name.split('-scan-')[0] for p in paths}=={'claude','codex'},paths
handles=[];started=time.time()
try:
 for path in paths:
  f=path.open('r');handles.append(f);fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 status.write_text(json.dumps({'status':'holding','started':started,'expires':started+14400,'locks':[str(p) for p in paths],'release_file':str(release)},indent=2)+'\n')
 print('Usage scan locks held; write release marker to restore; automatic limit 4 hours.',flush=True)
 while time.time()<started+14400 and not release.exists():time.sleep(1)
finally:
 for f in handles:f.close()
 status.write_text(json.dumps({'status':'released','started':started,'released':time.time(),'locks':[str(p) for p in paths]},indent=2)+'\n')
 print('Usage scan locks released.',flush=True)
