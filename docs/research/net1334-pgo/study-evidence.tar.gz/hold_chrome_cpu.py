"""Bound desktop background CPU during timing; restore runtime settings automatically."""
import json,subprocess,time
from pathlib import Path
root=Path('/tmp/rival-pgo/study');status=root/'chrome-cpu-hold-1.json';release=root/'chrome-cpu-hold-1.release'
units=['app-com.google.Chrome-108991.scope',r'app-Hyprland-google\x2dchrome\x2dstable-367d966f.scope']
assert not status.exists() and not release.exists()
def show(unit):
 text=subprocess.check_output(['systemctl','--user','show',unit,'-p','CPUQuotaPerSecUSec','-p','CPUQuotaPeriodUSec','-p','ActiveState','-p','ControlGroup'],text=True)
 return dict(line.split('=',1) for line in text.splitlines())
original={unit:show(unit) for unit in units}
for unit,properties in original.items():
 assert properties['ActiveState']=='active' and properties['CPUQuotaPerSecUSec']=='infinity', (unit,properties)
began=time.time();record={'status':'preparing','started':began,'expires':began+7200,'original':original,'temporary_cpu_quota':'5% per scope','release_file':str(release)};changed=[]
try:
 status.write_text(json.dumps(record,indent=2)+'\n')
 for unit in units:
  subprocess.run(['systemctl','--user','set-property','--runtime',unit,'CPUQuota=5%'],check=True);changed.append(unit)
 record.update(status='limited',applied={unit:show(unit) for unit in units});status.write_text(json.dumps(record,indent=2)+'\n');print('Temporary Chrome CPU quotas active; release marker or two-hour deadline restores unlimited quotas.',flush=True)
 while time.time()<began+7200 and not release.exists():time.sleep(1)
finally:
 failures=[]
 for unit in changed:
  result=subprocess.run(['systemctl','--user','set-property','--runtime',unit,'CPUQuota='],capture_output=True,text=True)
  if result.returncode:failures.append({'unit':unit,'error':result.stderr})
 record.update(status='restore_failed' if failures else 'restored',finished=time.time(),restore_failures=failures);status.write_text(json.dumps(record,indent=2)+'\n');print(record['status'],flush=True)
