import sys,json,hashlib,collections,re
from pathlib import Path
import chess,chess.pgn
sys.path.insert(0,'/home/chris/Work/rusty-rival/rusty-rival/scripts')
from compare_search_speed import sample_fens
root=Path('/tmp/rival-pgo');initial=json.loads((root/'positions.json').read_text());exclude={' '.join(f.split()[:4]) for f in sample_fens(Path('/home/chris/Work/rusty-rival/rusty-rival'))}
benchsrc=Path('/home/chris/Work/rusty-rival/rusty-rival/src/uci_bench.rs').read_text().split('const BENCH_FENS:')[1].split('];',1)[0]
exclude.update(' '.join(f.split()[:4]) for f in re.findall(r'"([^"]+)"',benchsrc))
exclude.update(' '.join(p['fen'].split()[:4]) for name in ['training','heldout'] for p in initial[name]);pools={'training':{},'heldout':{}}
for path in sorted((root/'calibration').glob('sf-*.pgn')):
 with path.open() as stream:
  while (game:=chess.pgn.read_game(stream)) is not None:
   assert not game.errors
   moves=list(game.mainline_moves());group=' '.join(m.uci() for m in moves[:16]);group_hash=hashlib.sha256(group.encode()).hexdigest();part='heldout' if int(group_hash[:8],16)%3==0 else 'training';board=game.board()
   for ply,move in enumerate(moves,1):
    board.push(move)
    if ply<60 or ply%20 or len(board.piece_map())>13 or board.is_game_over():continue
    fen=board.fen(en_passant='fen');key=' '.join(fen.split()[:4])
    if key in exclude:continue
    pools[part].setdefault(key,{'fen':fen,'suite':'v68-calibration','source_pgn':path.name,'round':game.headers['Round'],'opening_group_sha256':group_hash,'ply':ply,'bucket':min(7,(len(board.piece_map())-2)//4)})
print('Available', {k:dict(collections.Counter(p['bucket'] for p in pool.values())) for k,pool in pools.items()})
# Quotas cover NNUE output buckets 0,1,2; no binary output used.
quotas={'training':{0:4,1:6,2:6},'heldout':{0:2,1:3,2:3}}
result=dict(initial)
for part,qs in quotas.items():
 selected=[]
 for bucket,n in qs.items():
  options=[p for p in pools[part].values() if p['bucket']==bucket];options.sort(key=lambda p:hashlib.sha256(('rival-pgo-endgames-v1:'+p['fen']).encode()).hexdigest());assert len(options)>=n,(part,bucket,len(options),n);selected+=options[:n]
 result[part]=initial[part]+selected
keys=[{' '.join(p['fen'].split()[:4]) for p in result[part]} for part in ['training','heldout']];assert not keys[0]&keys[1]
result['endgame_selection']={'fixed_plies':'60,80,100,...','opening_group_split':'SHA256(first16UCI moves) first32bits modulo3==0 heldout, otherwise training','quotas':quotas,'rank':'SHA256(rival-pgo-endgames-v1:<FEN>)','source_archive_sha256':hashlib.sha256((root/'v68-calibration.tar.gz').read_bytes()).hexdigest()}
result['source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'calibration').glob('sf-*.pgn'))}
result['coverage']={}
for part in ['training','heldout']:
 boards=[chess.Board(p['fen']) for p in result[part]];result['coverage'][part]={'count':len(boards),'buckets':dict(collections.Counter(min(7,(len(b.piece_map())-2)//4) for b in boards)),'black_to_move':sum(not b.turn for b in boards),'root_in_check':sum(b.is_check() for b in boards),'castling':sum(bool(b.castling_rights) for b in boards),'ep':sum(b.ep_square is not None for b in boards)}
(root/'study/positions.json').write_text(json.dumps(result,indent=2)+'\n');print(result['coverage'])
