"""Make a deliberately invalid profile; never use its resulting binary for timing."""
import hashlib,json
from pathlib import Path
root=Path('/tmp/rival-pgo/study')
text=(root/'canary-source.proftext').read_text()
blocks=text.split('\n\n');changed=[];out=[]
for block in blocks:
 lines=block.splitlines()
 names=[(i,line) for i,line in enumerate(lines) if '11rusty_rival' in line and line.endswith(('6search6search','7quiesce7quiesce'))]
 if not names:out.append(block);continue
 assert ':ir' not in lines,'Refuse mutation in the IR-header block'
 assert len(names)==1
 i,name=names[0]
 if name.endswith('6search6search'):
  changed.append({'symbol':name,'mutation':'record removed'})
 else:
  assert lines[i+1]=='# Func Hash:'
  old=int(lines[i+2]);lines[i+2]=str(old^1)
  changed.append({'symbol':name,'mutation':'hash xor 1','old':old,'new':old^1})
  out.append('\n'.join(lines))
assert len(changed)==2 and {x['mutation'] for x in changed}=={'record removed','hash xor 1'}
p=root/'canary-invalid.proftext'
assert not p.exists(),'Retain first canary; use a fresh path for another attempt'
p.write_text('\n\n'.join(out))
(root/'canary-mutations.json').write_text(json.dumps({
 'source_profile_sha256':hashlib.sha256((root/'merged.profdata').read_bytes()).hexdigest(),
 'source_text_sha256':hashlib.sha256(text.encode()).hexdigest(),
 'mutations':changed,'canary_text_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'scope':'Diagnostic channel only; canary binary must never be timed or released.'
},indent=2)+'\n')
print('Prepared two deliberate profile mutations; no build.')
