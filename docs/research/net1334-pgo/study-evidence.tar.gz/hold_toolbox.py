"""Temporarily pause a verified background updater; always resume the same process."""
import json,os,signal,time
from pathlib import Path
root=Path('/tmp/rival-pgo/study');release=root/'toolbox-hold-1.release';status=root/'toolbox-hold-1.json';pid=2321
assert not release.exists() and not status.exists()
def identity():
 s=Path(f'/proc/{pid}/stat').read_text();end=s.rindex(')');fields=s[end+2:].split();return s[s.index('(')+1:end],fields[0],int(fields[19])
name,state,start=identity();assert name=='jetbrains-toolb' and state not in ('T','t'),(name,state)
exe=os.readlink(f'/proc/{pid}/exe');assert 'jetbrains-toolbox' in exe.lower(),exe
began=time.time();record={'pid':pid,'start_ticks':start,'executable':exe,'previous_state':state,'started':began,'expires':began+7200,'release_file':str(release)}
try:
 os.kill(pid,signal.SIGSTOP);record['status']='paused';status.write_text(json.dumps(record,indent=2)+'\n');print('Toolbox background updater paused; release marker or two-hour deadline resumes it.',flush=True)
 while time.time()<began+7200 and not release.exists():time.sleep(1)
finally:
 try:
  if identity()[2]==start:os.kill(pid,signal.SIGCONT)
 except ProcessLookupError:pass
 except FileNotFoundError:pass
 record.update(status='resumed',finished=time.time());status.write_text(json.dumps(record,indent=2)+'\n');print('Toolbox resumed.',flush=True)
