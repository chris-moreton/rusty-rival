"""Verify pinned LLVM PGO diagnostics using an intentionally invalid profile."""
import fcntl,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/tmp/rival-pgo/study')
lock=(root/'timing.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
source=Path('/tmp/rival-pgo/src')
target=root/'canary-target'
assert not target.exists(),'Fresh canary target directory required'
compiler=subprocess.check_output(['rustc','-Vv'],cwd=source,text=True)
frozen=json.loads((root/'provenance.json').read_text())
assert compiler==frozen['compiler'],'Canary must use the exact frozen study compiler'
toolchain=Path(subprocess.check_output(['rustc','--print','sysroot'],cwd=source,text=True).strip())
host=next(line.split(': ',1)[1] for line in compiler.splitlines() if line.startswith('host: '))
profdata=toolchain/'lib/rustlib'/host/'bin/llvm-profdata'
tree=hashlib.sha256()
for path in sorted(source.rglob('*')):
 if path.is_file():
  tree.update(str(path.relative_to(source)).encode()+b'\0')
  tree.update(hashlib.sha256(path.read_bytes()).digest())
invalid=root/'canary-invalid.profdata'
subprocess.run([str(profdata),'merge',str(root/'canary-invalid.proftext'),'-o',str(invalid)],check=True)
flags='-C link-args=-Wl,-z,stack-size=8388608 -C target-cpu=x86-64-v3 -C profile-use='+str(invalid)+' -C llvm-args=-pgo-warn-missing-function'
env=dict(os.environ,RUSTFLAGS=flags,CARGO_TARGET_DIR=str(target))
env.pop('CARGO_ENCODED_RUSTFLAGS',None);env.pop('LLVM_PROFILE_FILE',None)
log=root/'canary-build.log'
command=['cargo','build','--offline','--locked','--bin','rusty-rival','--release','--target','x86_64-unknown-linux-gnu','--manifest-path',str(source/'Cargo.toml')]
with log.open('w') as f:
 result=subprocess.run(command,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT)
lines=log.read_text().splitlines()
missing=[line for line in lines if 'no profile data' in line.lower() and '11rusty_rival' in line and '6search6search' in line]
mismatch=[line for line in lines if ('hash mismatch' in line.lower() or 'control flow change detected' in line.lower()) and '11rusty_rival' in line and '7quiesce7quiesce' in line]
binary=target/'x86_64-unknown-linux-gnu/release/rusty-rival'
binary_sha=hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None
if binary.exists():binary.chmod(0)
all_missing=[line for line in lines if 'no profile data' in line.lower()]
all_mismatch=[line for line in lines if 'hash mismatch' in line.lower() or 'control flow change detected' in line.lower()]
report={'source_commit':frozen['source_commit'],
 'source_tree_sha256':tree.hexdigest(),
 'source_scope':'Frozen study source archive. Future production adds toolchain pin; compiler must equal this recorded compiler.',
 'canary_binary_sha256':binary_sha,'canary_binary_permissions':'000; never execute',
 'all_missing_count':len(all_missing),'all_mismatch_count':len(all_mismatch),
 'engine_missing_lines':[line for line in all_missing if '11rusty_rival' in line],
 'engine_mismatch_lines':[line for line in all_mismatch if '11rusty_rival' in line],
 'compiler':compiler,'command':command,'rustflags':flags,'exit_code':result.returncode,
 'missing_search_diagnostics':missing,'mismatched_quiesce_diagnostics':mismatch,
 'passed':bool(missing and mismatch and result.returncode==0),
 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'invalid_profile_sha256':hashlib.sha256(invalid.read_bytes()).hexdigest(),
 'binary_policy':'Deliberately invalid profile; binary must never be timed or released.'}
(root/'canary-report.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['passed'],report
print('Diagnostic canary passed; evidence saved. Canary binary excluded from all timing.',flush=True)
