"""Paired fixed-node timing on frozen, never-trained positions (one thread)."""
import argparse,hashlib,json,math,os,re,statistics,time
from pathlib import Path
import sys
sys.path.insert(0,'/home/chris/Work/rusty-rival/rusty-rival/scripts')
from compare_search_speed import Engine
p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--hash-mb',type=int,default=128);a=p.parse_args();os.sched_setaffinity(0,{2})
paths=[a.baseline,a.candidate];fens=[x['fen'] for x in json.loads(Path('/tmp/rival-pgo/study/positions.json').read_text())['heldout']]
r={'nodes_requested':1000000,'threads':1,'hash_mb':a.hash_mb,'hash_entries':1<<((a.hash_mb*1024*1024//24).bit_length()-1),'cpu':2,'fens':fens,'binaries':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in paths],'warmups':[],'blocks':[]};reference={}
assert r['binaries'][0]['sha256'] != r['binaries'][1]['sha256'], 'Identical binaries'
assert 'LLVM_PROFILE_FILE' not in os.environ, 'Profiling environment present'
assert 'RIVAL_NET365_DIAGNOSTIC' not in os.environ, 'Diagnostic environment present'
last_attempt={}
for binary in paths:
 assert b'__llvm_profile_' not in binary.read_bytes(), 'Instrumented binary supplied'

def save():a.output.write_text(json.dumps(r,indent=2)+'\n')
def run(arm):
 global last_attempt
 records=[]
 for i,fen in enumerate(fens):
  last_attempt={'arm':arm,'index':i,'fen':fen}
  e=Engine(paths[arm]);e.send(f'setoption name Hash value {a.hash_mb}');e.send('isready');e.until('readyok')
  try:
   e.send('position fen '+fen);e.send('isready');ready=e.until('readyok');assert not any(re.search(r'\b(error|invalid|illegal)\b',x,re.I) for x in ready),ready
   start=time.perf_counter();e.send('go nodes 1000000');lines=e.until('bestmove');elapsed=time.perf_counter()-start
   assert not any(re.search(r'\b(error|invalid|illegal|panicked)\b',x,re.I) for x in lines),lines
   trace=[re.sub(r'\s+(?:time|nps|hashfull|tbhits)\s+\d+','',x) for x in lines if x.startswith('info depth ')]+[lines[-1]];assert len(trace)>1
   digest=hashlib.sha256(json.dumps(trace).encode()).hexdigest()
   if i not in reference:assert arm==0;reference[i]=digest
   last_attempt.update({'expected_digest':reference[i],'got_digest':digest,'lines':lines})
   assert digest==reference[i],(arm,i,'identity divergence')
   records.append({'index':i,'wall_seconds':elapsed,'trace_sha256':digest,'lines':lines})
  finally:e.close()
 return {'arm':arm,'seconds':sum(x['wall_seconds'] for x in records),'records':records}
try:
 r['warmups']=[run(0),run(1)];save()
 for i in range(20):
  runs=[run(x) for x in ([0,1,1,0] if i%2==0 else [1,0,0,1])];means=[statistics.mean(x['seconds'] for x in runs if x['arm']==arm) for arm in [0,1]];r['blocks'].append({'runs':runs,'log_speed_ratio':math.log(means[0]/means[1])});save();print('Heldout block',i+1,flush=True)
 v=[b['log_speed_ratio'] for b in r['blocks']];m=statistics.mean(v);d=2.093*statistics.stdev(v)/math.sqrt(20);r['speed_percent']=100*math.expm1(m);r['ci95_percent']=[100*math.expm1(m-d),100*math.expm1(m+d)];r['per_position_speed_percent']={str(i):100*math.expm1(statistics.mean(math.log(statistics.mean(run['records'][i]['wall_seconds'] for run in block['runs'] if run['arm']==0)/statistics.mean(run['records'][i]['wall_seconds'] for run in block['runs'] if run['arm']==1)) for block in r['blocks'])) for i in range(len(fens))};r['accepted']=r['speed_percent']>=3 and r['ci95_percent'][0]>0;save();print({k:r[k] for k in ['speed_percent','ci95_percent','accepted']},flush=True)
except BaseException as ex:
 r['failure']={'type':type(ex).__name__,'message':str(ex),**last_attempt};save();raise
