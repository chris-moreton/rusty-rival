"""Frozen baseline qualification and paired SMP non-inferiority validation."""
import argparse,hashlib,json,math,os,re,statistics,sys,time
from pathlib import Path
import chess
sys.path.insert(0,'/home/chris/Work/rusty-rival/rusty-rival/scripts')
from compare_search_speed import Engine
p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('--mode',choices=['qualify','aa','ab'],required=True);p.add_argument('--allow-aa',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent;os.sched_setaffinity(0,set(range(16)));paths=[a.baseline,a.candidate];hashes=[hashlib.sha256(x.read_bytes()).hexdigest() for x in paths];assert 'LLVM_PROFILE_FILE' not in os.environ;assert 'RIVAL_NET365_DIAGNOSTIC' not in os.environ
for binary in paths:assert b'__llvm_profile_' not in binary.read_bytes()
assert (a.mode=='ab' and hashes[0]!=hashes[1]) or (a.mode=='aa' and a.allow_aa and hashes[0]==hashes[1]) or a.mode=='qualify'
max_depth=int(re.search(r'pub const MAX_DEPTH:\s*\w+\s*=\s*(\d+)',Path('/home/chris/Work/rusty-rival/rusty-rival/src/engine_constants.rs').read_text())[1])
r={'mode':a.mode,'cpus':list(range(16)),'threads':16,'hash_mb':512,'hash_entries':16777216,'hash_actual_bytes':402653184,'movetime_ms':2000,'ponder':False,'idle_seconds':2,'binaries':[{'path':str(x),'sha256':h} for x,h in zip(paths,hashes)],'max_depth':max_depth,'warmups':[],'blocks':[],'qualification':[]};last_record=None

def save():a.output.write_text(json.dumps(r,indent=2)+'\n')
def diagnostic():
 freq={};temps={}
 for i in range(16):
  path=Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq')
  if path.exists():freq[i]=int(path.read_text())
 for path in Path('/sys/class/hwmon').glob('hwmon*/temp*_input'):
  try:temps[str(path)]=int(path.read_text())
  except (OSError,ValueError):pass
 return {'time':time.time(),'frequency_khz_snapshots':freq,'temperature_millic_snapshots':temps}
def engine(path):
 global last_record
 e=Engine(path)
 try:
  e.send('setoption name Threads value 16');e.send('setoption name Hash value 512');e.send('setoption name Ponder value false');e.send('isready');lines=e.until('readyok');last_record={'phase':'configure','lines':lines};assert not any(re.search(r'\b(error|invalid|illegal)\b',x,re.I) for x in lines),lines;return e
 except BaseException:e.close();raise
def search(e,fen):
 global last_record
 e.send('ucinewgame');e.send('position fen '+fen);e.send('isready');ready=e.until('readyok');assert not any(re.search(r'\b(error|invalid|illegal)\b',x,re.I) for x in ready)
 start=time.monotonic();e.send('go movetime 2000');lines=e.until('bestmove');wall=time.monotonic()-start
 last_record={'fen':fen,'lines':lines,'wall_seconds':wall}
 info=next(x for x in reversed(lines) if ' nodes ' in x and ' time ' in x);nodes=int(re.search(r' nodes (\d+)',info)[1]);ms=int(re.search(r' time (\d+)',info)[1]);depth=int(re.search(r' depth (\d+)',info)[1]);score=re.search(r' score (cp|mate) (-?\d+)',info);move=lines[-1].split()[1]
 legal=chess.Move.from_uci(move) in chess.Board(fen).legal_moves;errors=any(re.search(r'\b(error|invalid|illegal|panicked)\b',x,re.I) for x in lines)
 last_record={'fen':fen,'nodes':nodes,'time_ms':ms,'wall_seconds':wall,'depth':depth,'score_kind':score[1],'score':int(score[2]),'bestmove':move,'legal':legal,'lines':lines,'valid_duration':1950<=ms<=2500 and 1.95<=wall<4,'nonmate':score[1]=='cp' and abs(int(score[2]))<9000,'depth_margin':depth<max_depth-8,'protocol_ok':not errors}
 last_record['qualifies']=all(last_record[k] for k in ['legal','valid_duration','nonmate','depth_margin','protocol_ok']);return last_record
def run(arm,fens):
 records=[];before=diagnostic();e=engine(paths[arm])
 try:
  for fen in fens:
   record=search(e,fen);records.append(record);assert record['qualifies'],record
 finally:e.close()
 after=diagnostic();time.sleep(2);return {'arm':arm,'records':records,'nodes':sum(x['nodes'] for x in records),'time_ms':sum(x['time_ms'] for x in records),'before':before,'after':after}
try:
 if a.mode=='qualify':
  positions=json.loads((root/'positions.json').read_text())['heldout'];ordered=sorted(positions,key=lambda p:hashlib.sha256(p['fen'].encode()).hexdigest());selected=[]
  for low,count in [(True,2),(False,6)]:
   chosen=[]
   for position in ordered:
    if (sum(c.isalpha() for c in position['fen'].split()[0])<=13)!=low:continue
    trials=[]
    for repeat in range(3):
     e=engine(paths[0])
     try:trials.append(search(e,position['fen']))
     finally:e.close()
     time.sleep(2)
    ok=all(x['qualifies'] for x in trials);r['qualification'].append({'position':position,'trials':trials,'qualified':ok});save()
    if ok:chosen.append(position)
    if len(chosen)==count:break
   assert len(chosen)==count,('Insufficient qualifying positions',low,len(chosen))
   selected+=chosen
  r['selected']=selected;save();(root/'smp-selected.json').write_text(json.dumps({'positions':selected,'qualification_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest()},indent=2)+'\n');print('Qualified',len(selected),'positions',flush=True)
 else:
  fens=[x['fen'] for x in json.loads((root/'smp-selected.json').read_text())['positions']];r['fens']=fens;r['warmups']=[run(0,fens),run(1,fens)];save();blocks=10 if a.mode=='aa' else 20
  for i in range(blocks):
   runs=[run(x,fens) for x in ([0,1,1,0] if i%2==0 else [1,0,0,1])];rates=[sum(x['nodes'] for x in runs if x['arm']==arm)/sum(x['time_ms'] for x in runs if x['arm']==arm) for arm in [0,1]];r['blocks'].append({'runs':runs,'log_speed_ratio':math.log(rates[1]/rates[0])});save();print(a.mode,'block',i+1,'/',blocks,flush=True)
  ratios=[b['log_speed_ratio'] for b in r['blocks']];m=statistics.mean(ratios);err=(2.262 if blocks==10 else 2.093)*statistics.stdev(ratios)/math.sqrt(blocks);r['speed_percent']=100*math.expm1(m);r['ci95_percent']=[100*math.expm1(m-err),100*math.expm1(m+err)];r['halfwidth_pp']=(r['ci95_percent'][1]-r['ci95_percent'][0])/2;r['accepted']=(r['halfwidth_pp']<=0.75 and r['ci95_percent'][0]<=0<=r['ci95_percent'][1]) if a.mode=='aa' else r['ci95_percent'][0]>-1;save();print({k:r[k] for k in ['speed_percent','ci95_percent','halfwidth_pp','accepted']},flush=True)
except BaseException as ex:
 r['failure']={'type':type(ex).__name__,'message':str(ex),'last_record':last_record};save();raise
