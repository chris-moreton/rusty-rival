"""Run unchanged comparison harness, retaining independent CPU-load samples."""
import json
from pathlib import Path
import subprocess
import time

def sample():
    return {x.split()[0]:list(map(int,x.split()[1:])) for x in Path('/proc/stat').read_text().splitlines() if x.startswith('cpu')}

base=Path('/tmp/rival-pgo/study')
with (base/'comparison-avx2-clean.log').open('w') as log, (base/'cpu-load-clean.jsonl').open('w') as monitor:
    a=sample()
    p=subprocess.Popen(['python3','scripts/compare_search_speed.py','/tmp/rival-pgo/study/baseline/x86_64-unknown-linux-gnu/release/rusty-rival',str(base/'candidate/x86_64-unknown-linux-gnu/release/rusty-rival'),'--output',str(base/'comparison-avx2-clean.json')],stdout=log,stderr=subprocess.STDOUT)
    while p.poll() is None:
        time.sleep(2)
        b=sample()
        busy={}
        for k in a:
            delta=[y-x for x,y in zip(a[k],b[k])]
            total=sum(delta[:8])
            busy[k]=round(100*(total-delta[3]-delta[4])/total,2) if total else 0
        monitor.write(json.dumps({'time':time.time(),'busy_percent':busy})+'\n')
        monitor.flush()
        a=b
    raise SystemExit(p.returncode)
