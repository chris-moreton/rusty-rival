"""Host-level CPU contention guard for paired timing runs.

Why /proc/stat and not ps: a sandboxed process sees only its own PID namespace,
so `ps` cannot prove the host is idle (NET-PGO first primary run: sandbox ps saw
nothing while the host ran a 16-thread engine at 1569%). /proc/stat and
/proc/loadavg report host-wide counters regardless of PID namespace (unless the
sandbox mounts lxcfs, which this one does not - the monitor that caught the
contention read /proc/stat).

Model: the harness reserves a CPU set for the engine. Everything else - and in
particular the SMT siblings of the reserved CPUs - must be idle. The guard never
measures the reserved CPUs themselves (they are expected to be ~100% busy).

Policy is preregistered, not adaptive: a contaminated window invalidates the run.
Because a single contaminated block invalidates the whole run anyway, aborting at
the first contaminated window loses nothing and saves the remaining blocks.

Usage (ST heldout, engine on CPU 2):

    guard = HostGuard(reserved={2}, output=Path('host-guard.jsonl'))
    guard.preflight()                  # raises HostBusy with evidence
    guard.start()
    ... for each block: run arms ...; guard.check_window('block', i)
    guard.stop()

SMP: HostGuard(reserved=set(range(16)), ...).  Siblings are derived from
/sys topology, so 16..31 are guarded automatically.
"""
import json
import threading
import time
from pathlib import Path


class HostBusy(RuntimeError):
    pass


def _cpu_times():
    out = {}
    for line in Path('/proc/stat').read_text().splitlines():
        if line.startswith('cpu') and line[3:4].isdigit():
            f = line.split()
            out[int(f[0][3:])] = list(map(int, f[1:]))
    return out


def _busy_percent(a, b):
    """Per-CPU busy % between two /proc/stat samples (idle = idle + iowait)."""
    res = {}
    for c in a:
        d = [y - x for x, y in zip(a[c], b[c])]
        total = sum(d[:8])
        res[c] = 100.0 * (total - d[3] - d[4]) / total if total else 0.0
    return res


def siblings_of(cpus):
    s = set()
    for c in cpus:
        txt = Path(f'/sys/devices/system/cpu/cpu{c}/topology/thread_siblings_list').read_text().strip()
        for part in txt.split(','):
            if '-' in part:
                lo, hi = map(int, part.split('-'))
                s.update(range(lo, hi + 1))
            else:
                s.add(int(part))
    return s - set(cpus)


class HostGuard:
    # Preregistered thresholds (percent busy). Tune before, never after, a run.
    PREFLIGHT_SECONDS = 10
    SAMPLE_SECONDS = 2
    MEAN_OTHER_MAX = 3.0      # mean busy over the window, all non-reserved CPUs
    MEAN_SIBLING_MAX = 3.0    # mean busy over the window, SMT siblings of reserved
    PEAK_SIBLING_MAX = 20.0   # any single sample on any sibling
    PEAK_OTHER_MAX = 50.0     # any single sample on any other CPU (a foreign engine thread pins at ~100)

    def __init__(self, reserved, output):
        self.reserved = set(reserved)
        self.siblings = siblings_of(self.reserved)
        self.other = set(_cpu_times()) - self.reserved - self.siblings
        self.output = Path(output)
        self._samples = []       # (time, {cpu: busy})
        self._stop = threading.Event()
        self._thread = None
        self._window_start = 0
        self._sampling_error = None

    # -- sampling --------------------------------------------------------
    def _sample_loop(self):
        try:
            self._sample_loop_inner()
        except BaseException as exc:
            self._sampling_error = exc

    def _sample_loop_inner(self):
        prev = _cpu_times()
        while not self._stop.wait(self.SAMPLE_SECONDS):
            cur = _cpu_times()
            busy = _busy_percent(prev, cur)
            prev = cur
            rec = {'time': time.time(), 'busy': busy, 'loadavg': Path('/proc/loadavg').read_text().split()}
            self._samples.append(rec)
            with self.output.open('a') as f:
                f.write(json.dumps(rec) + '\n')

    def start(self):
        self._thread = threading.Thread(target=self._sample_loop, daemon=True)
        self._thread.start()
        self._window_start = len(self._samples)

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join()

    # -- evaluation ------------------------------------------------------
    def _evaluate(self, samples, label):
        if not samples:
            raise HostBusy(f'{label}: no samples')
        def mean_over(cpus):
            vals = [s['busy'][c] for s in samples for c in cpus]
            return sum(vals) / len(vals) if vals else 0.0
        def peak_over(cpus):
            return max((s['busy'][c], c, s['time']) for s in samples for c in cpus) if cpus else (0.0, None, None)
        report = {
            'label': label,
            'samples': len(samples),
            'mean_sibling': mean_over(self.siblings),
            'mean_other': mean_over(self.other),
            'peak_sibling': peak_over(self.siblings),
            'peak_other': peak_over(self.other),
            'reserved': sorted(self.reserved),
            'siblings': sorted(self.siblings),
        }
        with self.output.open('a') as f:
            f.write(json.dumps({'window': report}) + '\n')
        bad = []
        if report['mean_sibling'] > self.MEAN_SIBLING_MAX:
            bad.append('mean_sibling')
        if report['mean_other'] > self.MEAN_OTHER_MAX:
            bad.append('mean_other')
        if report['peak_sibling'][0] > self.PEAK_SIBLING_MAX:
            bad.append('peak_sibling')
        if report['peak_other'][0] > self.PEAK_OTHER_MAX:
            bad.append('peak_other')
        if bad:
            raise HostBusy(f'{label}: host contention {bad}: {json.dumps(report)}')
        return report

    def preflight(self):
        """Blocking idle check before any engine starts. Raises HostBusy."""
        samples = []
        prev = _cpu_times()
        for _ in range(int(self.PREFLIGHT_SECONDS / self.SAMPLE_SECONDS)):
            time.sleep(self.SAMPLE_SECONDS)
            cur = _cpu_times()
            samples.append({'time': time.time(), 'busy': _busy_percent(prev, cur)})
            prev = cur
        with self.output.open('a') as f:
            for sample in samples:
                f.write(json.dumps({'preflight_sample': sample}) + '\n')
        # Before the engine runs, the reserved CPUs must be idle too.
        saved = self.other
        self.other = saved | self.reserved
        try:
            return self._evaluate(samples, 'preflight')
        finally:
            self.other = saved

    def check_window(self, kind, index):
        """Evaluate samples taken since the previous check. Raises HostBusy."""
        if self._sampling_error is not None:
            raise HostBusy(f'Host sampler failed: {self._sampling_error!r}')
        end = len(self._samples)
        samples = self._samples[self._window_start:end]
        self._window_start = end
        return self._evaluate(samples, f'{kind}-{index}')
