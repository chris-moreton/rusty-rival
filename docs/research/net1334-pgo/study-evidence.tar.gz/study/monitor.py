"""Guard a timing subprocess using host counters, preserving all failures."""
import argparse,fcntl,json,os,signal,subprocess,time
from pathlib import Path
from host_guard import HostGuard
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['single','smp'],required=True);p.add_argument('--prefix',type=Path,required=True);p.add_argument('--result',type=Path,required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.command[1:] if a.command[:1]==['--'] else a.command;assert cmd
assert str(a.result) in cmd, 'Command must write the monitored result path'
if a.mode=='single':
 for i,arg in enumerate(cmd):
  if arg=='--cpu':assert cmd[i+1]=='2', 'Single timing must use CPU 2'
  if arg.startswith('--cpu='):assert arg=='--cpu=2', 'Single timing must use CPU 2'
monitor_cpu=0 if a.mode=='single' else 31
os.sched_setaffinity(0,{monitor_cpu})
lock=(Path(__file__).resolve().parent/'timing.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
meta=Path(str(a.prefix)+'.monitor.json');logpath=Path(str(a.prefix)+'.log');cpu=Path(str(a.prefix)+'.cpu.jsonl');assert not any(x.exists() for x in [meta,logpath,cpu,a.result]),'Use fresh output paths'
r={'mode':a.mode,'command':cmd,'result':str(a.result),'status':'preflight','monitor_cpu':monitor_cpu};guard=HostGuard(reserved={2} if a.mode=='single' else set(range(16)),output=cpu);proc=None
r['thresholds']={k:getattr(guard,k) for k in ['PREFLIGHT_SECONDS','SAMPLE_SECONDS','MEAN_OTHER_MAX','MEAN_SIBLING_MAX','PEAK_SIBLING_MAX','PEAK_OTHER_MAX']}
def save():meta.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 guard.preflight();guard.start()
 with logpath.open('w') as log:
  proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=proc.pid;r['status']='running';save();last_block=0;last_warmup=0;last_signature=None
  while proc.poll() is None:
   time.sleep(1)
   try:
    stat=a.result.stat();signature=(stat.st_mtime_ns,stat.st_size)
    if signature==last_signature:continue
    data=json.loads(a.result.read_text());last_signature=signature
   except (FileNotFoundError,json.JSONDecodeError):continue
   warmup=len(data.get('warmups',[]))
   block=len(data.get('blocks',[]))
   if warmup>last_warmup and block==0:
    guard.check_window('warmup',warmup);last_warmup=warmup
   if block>last_block:guard.check_window('block',block);last_block=block
  # Evaluate remaining samples; no empty-window check after the final block.
  if guard._sampling_error is not None or len(guard._samples)>guard._window_start:guard.check_window('final',last_block)
  r['exit_code']=proc.returncode;r['status']='completed' if proc.returncode==0 else 'failed';save()
except BaseException as ex:
 r['status']='INVALID';r['failure']={'type':type(ex).__name__,'message':str(ex)};save();raise
finally:
 if proc is not None and proc.poll() is None:
  os.killpg(proc.pid,signal.SIGINT)
  try:proc.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 guard.stop()
raise SystemExit(0 if r['status']=='completed' else 1)
