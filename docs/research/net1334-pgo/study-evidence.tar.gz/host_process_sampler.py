"""Read-only host process CPU attribution; command names only, no arguments."""
import argparse,json,os,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=int,default=1800);p.add_argument('--cpu',type=int,default=0);a=p.parse_args()
os.sched_setaffinity(0,{a.cpu})
hz=os.sysconf('SC_CLK_TCK')
def sample():
 out={}
 for entry in Path('/proc').iterdir():
  if not entry.name.isdecimal():continue
  try:
   text=(entry/'stat').read_text();end=text.rindex(')');fields=text[end+2:].split()
   # fields begin at Linux proc stat field 3 (state).
   out[(int(entry.name),int(fields[19]))]=(text[text.index('(')+1:end],int(fields[11])+int(fields[12]))
  except (OSError,ValueError,IndexError):continue
 return out
with a.output.open('x') as f:
 f.write(json.dumps({'sampler_pid':os.getpid(),'cpu':a.cpu,'interval_seconds':0.5,'namespace_pid':os.readlink('/proc/self/ns/pid')})+'\n');f.flush()
 prev=sample();last=time.monotonic();deadline=last+a.seconds
 while time.monotonic()<deadline and not a.output.with_suffix('.stop').exists():
  time.sleep(0.5);now=time.monotonic();cur=sample();elapsed=now-last
  rows=[]
  for key,(name,ticks) in cur.items():
   if key in prev:
    percent=100*(ticks-prev[key][1])/hz/elapsed
    if percent>=5:rows.append({'pid':key[0],'start_ticks':key[1],'comm':name,'cpu_percent':round(percent,2)})
  f.write(json.dumps({'time':time.time(),'elapsed':elapsed,'processes':sorted(rows,key=lambda x:-x['cpu_percent'])})+'\n');f.flush()
  prev=cur;last=now
