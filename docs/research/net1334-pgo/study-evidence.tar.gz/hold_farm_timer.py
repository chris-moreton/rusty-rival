import json,subprocess,time
from pathlib import Path
r=Path('/tmp/rival-pgo/study');status=r/'farm-timer-hold-1.json';release=r/'farm-timer-hold-1.release';unit='farm-snapshot.timer'
assert not status.exists() and not release.exists()
def state(name):return subprocess.check_output(['systemctl','--user','show',name,'--value','-p','ActiveState'],text=True).strip()
assert state(unit)=='active';assert state('farm-snapshot.service') not in ('active','activating')
started=time.time();record={'unit':unit,'previous_state':'active','started':started,'expires':started+7200,'release_file':str(release)}
try:
 subprocess.run(['systemctl','--user','stop',unit],check=True);record['status']='deferred';status.write_text(json.dumps(record,indent=2)+'\n');print('Agent-farm snapshot timer deferred; automatic restoration within two hours.',flush=True)
 while time.time()<started+7200 and not release.exists():time.sleep(1)
finally:
 result=subprocess.run(['systemctl','--user','start',unit]);record.update(status='restored' if result.returncode==0 else 'restore_failed',finished=time.time());status.write_text(json.dumps(record,indent=2)+'\n');print(record['status'],flush=True)
